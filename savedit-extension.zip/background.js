// Background script for future use (e.g. context menu saving)
chrome.runtime.onInstalled.addListener(() => {
    console.log('Savedit extension installed');
});
